from django.urls import path,include
from myApp import views
from django.conf import settings
from django.conf.urls.static import static


urlpatterns = [
    
    path('',views.userlogin,name="login"),
    path('home/',views.home,name='home2'),
    path('cont/',views.cont,name='cont'),
    path('abt/',views.abt,name='abt'),
    path('login',views.userlogin,name="login"),
    path('signin',views.signin,name="signin"),
    path('signin/signin',views.signin,name="signin"),
    path('help/',views.help,name="help"),
    path('profile/',views.profile ,name="profile"),
    path('profile/home/',views.home ,name="profile"),
    path('logout/',views.signout,name="signout"),
    path('write/',views.write,name="write")
]