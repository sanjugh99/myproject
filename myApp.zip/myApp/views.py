from django import forms
from django.shortcuts import render,redirect
from .models import topics
from .models import latests
from .models import Profile
from .models import Post
from .form import PostForm, ProfileForm
from django.contrib.auth.models import User,auth
from django.contrib import messages
from django.contrib.sessions.models import Session
from django.views.generic import ListView, DetailView

    
def display(request):
    if request.session.has_key('is_logged'):
        if request.method =="GET":
            posts=Post.objects.all()
            return render(request,"write.html",{'posts':posts})
    return redirect('/')



def home(request):
    if request.session.has_key('is_logged'):
        name=request.session.get('id')    
        check=User.objects.filter(username=name)
        print(check)
        user=User.objects.get(username=name)
        if user.is_active:
            loguser=Profile.objects.get(name=name)
            arts=Post.objects.all()
            for i in arts:
              print(i.name)
            
            return render(request,'home2.html',{'loguser':loguser ,'write':arts})
        return render(request,'home2.html')
        if request.method =="GET":
           arts=Post.objects.all()
           return render(request,"write.html",{'write':arts})
    return redirect('/')
  

def userlogin(request):
    if request.method =='POST':
        if request.POST.get('username') and request.POST.get('password'):
            # savlog=Profile()
            name= request.POST.get('username')
            password= request.POST.get('password')
            # savlog.save()
            user=auth.authenticate(username=name , password=password)
            if user is not None:
                auth.login(request,user)
                # messages.info(request,'Invalid Credential')
                request.session['is_logged']= True
                request.session['id']=name
                return redirect('home/')
            else:
                messages.error(request,'Invalid Credential')
                return redirect('/')
        else:
            return render(request,'home2.html') 

    else:
        return render(request,'login.html')   

def signin(request):
    if request.method == 'POST':
        savst=Profile()
        password1=request.POST.get('password1')
        password2=request.POST.get('password2')
        name=request.POST.get('uname')
        email=request.POST.get('email')
        phno=request.POST.get('phno')
        if password1==password2:
            if User.objects.filter(username=name).exists():
                 messages.error(request,'Username Taken')
                 return redirect('signin')
            elif User.objects.filter(email=email).exists():
                 messages.error(request,'This ID already Taken')
                 return redirect('signin')
            elif Profile.objects.filter(phno=phno).exists():
                 messages.error(request,'This phno already Taken')
                 return redirect('signin')
        # if request.POST.get('uname') and request.POST.get('email') and request.POST.get('phno') and request.POST.get('password1') and request.POST.get('password2') and request.POST.get('description') and request.POST.get('topic') and request.POST.get('img'):
            else:
                savst.name= request.POST.get('uname')
                savst.email= request.POST.get('email')
                savst.password1= request.POST.get('password1')
                savst.password2= request.POST.get('password2')
                savst.phno=request.POST.get('phno')
                savst.description=request.POST.get('description')
                savst.topic=request.POST.get('topic')
                # savst.img=request.POST.get('img')
                savst.save()
                messages.success(request,'User has been created successfully')
                user= User.objects.create_user(username=name,email=email,password=password1)
                return redirect('login')
        
        else:
            messages.warning(request,'Password is not matching')
            return redirect('signin')
    else:
        return render(request,'signin.html')
            
def signout(request,name):
    auth.logout(request)
    return redirect('/')
 
def profile(request):
    if request.session.has_key('is_logged'):
        name=request.session.get('id')
        print(request.session.get('id'))
        check=User.objects.filter(username=name)
        print(check)
        user=User.objects.get(username=name)
        if user.is_active:
            loguser=Profile.objects.get(name=name)
            return render(request,'profile.html',{'loguser':loguser})
        return render(request,'profile.html')
    return redirect('/')







def write(request):
    if request.session.has_key('is_logged'):
        name=request.session.get('id')
        svpost=Post()
        if request.method == 'POST':
            form=PostForm(request.POST,instance=svpost)
            print(form)
            if form.is_valid():
                form.save()
                return redirect('/home/')
        else:
            form=PostForm()
            return render(request,'write.html',{'form':form})
    return redirect('/')


    
def display(request):
    if request.session.has_key('is_logged'):
        if request.method =="GET":
            posts=Post.objects.all()
            return render(request,"write.html",{'posts':posts})
    return redirect('/')


def help(request):
    if request.session.has_key('is_logged'):
        return render(request,"help.html")
    return redirect('/')

def abt(request):   
    return render(request,"abt.html")

def cont(request):   
    return render(request,"cont.html")

def art_image_view(request):
    if request.method=='POST':
        form = PostForm(request.POST, request.FILES)
        print(form)
        if form.is_valid():
            form.save()
            if request.method =="GET":
                arts=Post.objects.all()
                return render(request,"write.html",{'arts':arts})
            else:
                 form=PostForm()
                 return render(request,'write.html',{'form':form})
        else:
                 form=PostForm()
                 return render(request,'write.html',{'form':form})

    else:
        form=PostForm()
        img=Post.objects.all()
        return render(request,'write.html',{"img":img,"form":form})


def display(request):
    if request.method =="GET":
        arts=Post.objects.all()
        return render(request,"write.html",{'write':arts})

