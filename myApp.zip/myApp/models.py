from django.db import models
from django.contrib.auth.models import User
from ckeditor.fields import RichTextField
from datetime import datetime


class topics(models.Model):
    # topic_id=models.IntegerField()
    name=models.CharField(max_length=100)
    img=models.ImageField(upload_to='pics')
    des=models.CharField(max_length=100)


class latests(models.Model):
    img=models.ImageField(upload_to='pics')
    title=models.CharField(max_length=100)
    desc1=models.CharField(max_length=100)
    desc2=models.CharField(max_length=100)


class Profile(models.Model):
    name=models.CharField(max_length=50)
    email=models.EmailField(max_length=50)
    phno=models.IntegerField()
    password1=models.CharField(max_length=50)
    password2=models.CharField(max_length=50)
    description=models.CharField(max_length=200)
    topic=models.CharField(max_length=200)
    img=models.ImageField(upload_to="image",null=True, blank=True,default="image/defaultprofile.jpg")
    
    def __str__(self):
        return self.name
    
    
class Post(models.Model):
    title=models.CharField(max_length=100)
    name=models.ForeignKey(Profile, on_delete=models.CASCADE)
    body=RichTextField(blank=True, null=True)
    post_at=models.DateTimeField(default=datetime.now,blank=True)
 
class Answer(models.Model):
    name=models.ForeignKey(Post, on_delete=models.CASCADE)
    answer=models.CharField(max_length=200)
    post_at=models.DateTimeField(default=datetime.now,blank=True)




   