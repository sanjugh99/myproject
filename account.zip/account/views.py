from django.shortcuts import render, redirect

from .forms import *

# Create your views here.
def art_image_view(request):
    if request.method=='POST':
        form = ArtForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            if request.method =="GET":
                arts=Art.objects.all()
                return render(request,"art.html",{'arts':arts})
            else:
                 form=ArtForm()
                 return render(request,'art.html',{'form':form})
        else:
                 form=ArtForm()
                 return render(request,'art.html',{'form':form})

    else:
        form=ArtForm()
        img=Art.objects.all()
        return render(request,'art.html',{"img":img,"form":form})

def comment(request):
    return render(request,'artcomment.html')
def display(request):
    if request.method =="GET":
        arts=Art.objects.all()
        return render(request,"art.html",{'arts':arts})
# def upload(request):
#     return re



