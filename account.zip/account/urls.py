from django.contrib import admin
from django.urls import path , include
from django.conf import settings
from django.conf.urls.static import static
from django.urls.resolvers import URLPattern
from account import views
urlpatterns = [
    path('',views.art_image_view,name="art_image_view"), 
    path('display/',views.display,name="display"), 
    path('display/comment/',views.comment,name="comment"), 

]