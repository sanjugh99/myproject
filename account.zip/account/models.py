from django.db import models
from ckeditor.fields import RichTextField
from datetime import datetime


# Create your models here.
# class Art(models.Model):
#     description=models.CharField(max_length=200)
#     image=models.ImageField(upload_to="img/%y")
#     name=models.CharField(max_length=50)

class Art(models.Model):
    description=RichTextField(blank=True, null=True)
    # image=models.ImageField(upload_to="img/%y")
    tittle=models.CharField(max_length=50)
    post_at=models.DateTimeField(default=datetime.now,blank=True)
    
